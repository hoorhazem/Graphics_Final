1. Enter every Grid U have and in the "Tilemap Collider 2D" ==> Check "Used By Composite"(make it True)

2. In the Top-Right Corner of the Inspector U will find something named Layer and its value is "Default" ==> Select another value and select "Add Layer..." after that in "User Layer 6" write in it "Ground"

3. Enter every Grid Again then from The Layer ==> choose "Ground" (that u had writed it will appear)

4. In the "Player" folder In "Prefab" folder ==> Drag and Drop the "Player" in the Scene (Now U have a player but we need to check somethings to make sure it works right)

5. Click on the "Player" in the Scene in the Inspector u will find "Player Movement (Script)" in it make Sure Everything is Ok as the ScreenShot

6. Now for the "Camera" open "Scripts" folder ==> Drag and Drop "CameraFollow" script to the "Main Camera" in the "Hierarchy"

7. Select "Main Camera" from the "Hierarchy" in the "Inspector" U will find "Camera Follow (Script)" (that u had added) ==> Drag and Drop "Player" from "Hierarchy" to the "Player" part in the "Inspector"